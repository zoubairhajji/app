angular.module('images', [])
    .controller('ImagesController', ['$scope', 'Image', 'ViewSpinner', 'Messages',
        function ($scope, Image, ViewSpinner, Messages) {
            $scope.sortType = 'Created';
            $scope.sortReverse = true;
            $scope.toggle = false;

            $scope.order = function(sortType) {
                $scope.sortReverse = ($scope.sortType === sortType) ? !$scope.sortReverse : false;
                $scope.sortType = sortType;
            };

            $scope.showBuilder = function () {
                $('#build-modal').modal('show');
            };

            $scope.removeAction = function () {
                ViewSpinner.spin();
                var counter = 0;
                var complete = function () {
                    counter = counter - 1;
                    if (counter === 0) {
                        ViewSpinner.stop();
                    }
                };
                angular.forEach($scope.images, function (i) {
                    if (i.Checked) {
                        counter = counter + 1;
                        Image.remove({id: i.Id}, function (d) {
                            angular.forEach(d, function (resource) {
                                Messages.send("Image deleted", resource.Deleted);
                            });
                            var index = $scope.images.indexOf(i);
                            $scope.images.splice(index, 1);
                            complete();
                        }, function (e) {
                            Messages.error("Failure", e.data);
                            complete();
                        });
                    }
                });
            };

            $scope.toggleSelectAll = function () {
                angular.forEach($scope.filteredImages, function (i) {
                    i.Checked = $scope.toggle;
                });
            };

            ViewSpinner.spin();
            Image.query({}, function (d) {
                $scope.images = d.map(function (item) {
                    return new ImageViewModel(item);
                });
                ViewSpinner.stop();
            }, function (e) {
                Messages.error("Failure", e.data);
                ViewSpinner.stop();
            });
        }]);
