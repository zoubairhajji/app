# UI For Docker with Swarm

This example works with swarm clusters created with docker-machine.

## Usage

Make sure your client is pointed directly to the Docker daemon on the swarm-master's node (not through swarm).

```
docker-compose up -d
```
